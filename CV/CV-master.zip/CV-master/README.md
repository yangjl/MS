CV
==

### Curriculum Vitae for Jeffrey Ross-Ibarra

**update.sh**: uses scholar library from R (file h.r) to update H-Index and total citations, runs pdflatex to generate new pdf.

**update.pl**: uses citation data from h.r to update citation counts in CV. embarassing perl code!

**CV.temp.tex**: edit this one.

**CV.tex**: cite/publish/use this one.
