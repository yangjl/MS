perl update.pl
pdflatex CV.tex

git commit -am "update";
git push
